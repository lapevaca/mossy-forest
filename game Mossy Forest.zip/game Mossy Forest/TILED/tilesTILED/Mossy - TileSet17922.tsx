<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.1" name="Mossy - TileSet17922" tilewidth="77" tileheight="77" tilecount="49" columns="7">
 <image source="CHARSprites/Mossy Assets/Mossy Tileset/Mossy - TileSet17922.png" width="539" height="539"/>
</tileset>
