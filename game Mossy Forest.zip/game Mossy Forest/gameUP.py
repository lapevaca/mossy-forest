import pygame, sys  # импорт библиотек pygame и sys
from csv import reader
from os import walk
from math import sin

# инициализация игры
pygame.init()

# константы для уровня
tileSIZE = 77
screen_width = 1350
screen_height = 750

# создание экрана игры
screen = pygame.display.set_mode((screen_width, screen_height))
pygame.display.set_caption('Mossy forest')
clock = pygame.time.Clock()


# импорт изображений для анимации
def import_folder(path):
    surf = []
    for i, j, img_file in walk(path):
        for image in img_file:
            full_path = path + '/' + image
            image_surf = pygame.image.load(full_path).convert_alpha()
            surf.append(image_surf)
    return surf


# импорт всех слоев
def import_csv_layout(path):
    tile_MAP = []
    with open(path) as map:
        level = reader(map, delimiter=',')
        for i in level:
            tile_MAP.append(list(i))
        return tile_MAP


# импорт разрезанных спрайтов для плиток
def import_cut(path):
    surface = pygame.image.load(path).convert_alpha()

    tileNUMX = int(surface.get_size()[0] / tileSIZE)
    tileNUMY = int(surface.get_size()[1] / tileSIZE)

    cut_tiles = []
    for row in range(tileNUMY):
        for col in range(tileNUMX):
            x = col * tileSIZE
            y = row * tileSIZE
            new_surface = pygame.Surface((tileSIZE, tileSIZE), pygame.SRCALPHA, 32)
            new_surface.blit(surface, (0, 0), pygame.Rect(x, y, tileSIZE, tileSIZE))
            cut_tiles.append(new_surface)
    return cut_tiles


# родительский класс для прорисовки всех плиток
class TILE(pygame.sprite.Sprite):
    def __init__(self, size, x, y):
        super().__init__()
        self.image = pygame.Surface((tileSIZE, tileSIZE))
        self.rect = self.image.get_rect(topleft=(x, y))


# дочерний класс для прорисовки статичных спрайтов
class STATICFILE(TILE):
    def __init__(self, size, x, y, surface):
        super().__init__(size, x, y)
        self.image = surface


class COIN(STATICFILE):
    def __init__(self, size, x, y):
        super().__init__(size, x, y, pygame.image.load("SPRITES/otherSprites/light.png").convert_alpha())
        offset_y = y + size
        self.rect = self.image.get_rect(bottomleft=(x, offset_y))


class VINE(STATICFILE):
    def __init__(self, size, x, y):
        super().__init__(size, x, y, pygame.image.load("SPRITES/otherSprites/vine1.png").convert_alpha())
        offset_y = y + size
        self.rect = self.image.get_rect(bottomleft=(x, offset_y))


class PLANT(STATICFILE):
    def __init__(self, size, x, y):
        super().__init__(size, x, y, pygame.image.load("SPRITES/otherSprites/vine6.png").convert_alpha())
        offset_y = y + size
        self.rect = self.image.get_rect(bottomleft=(x, offset_y))


class SPIKES(STATICFILE):
    def __init__(self, size, x, y):
        super().__init__(size, x, y, pygame.image.load("SPRITES/otherSprites/plant6.png").convert_alpha())
        offset_y = y + size
        self.rect = self.image.get_rect(bottomleft=(x, offset_y))


# два следующих класса: прорисовка двух типов камней на карте
class ROCKTALL(STATICFILE):
    def __init__(self, size, x, y):
        super().__init__(size, x, y, pygame.image.load("SPRITES/otherSprites/plant3.png").convert_alpha())
        offset_y = y + size
        self.rect = self.image.get_rect(bottomleft=(x, offset_y))


class ROCKSMALL(STATICFILE):
    def __init__(self, size, x, y):
        super().__init__(size, x, y, pygame.image.load("SPRITES/otherSprites/plant1.png").convert_alpha())
        offset_y = y + size
        self.rect = self.image.get_rect(bottomleft=(x, offset_y))


# прорисовка анимированных спрайтов
class ANIMATEDSPRITES(TILE):
    def __init__(self, size, x, y, path):
        super().__init__(size, x, y)
        self.frames = import_folder(path)
        self.frame_index = 0

        self.image = self.frames[self.frame_index]
        offset_y = y + size
        self.rect = self.image.get_rect(bottomleft=(x, offset_y))

    def animate(self):
        self.frame_index += 0.3
        if self.frame_index >= len(self.frames):
            self.frame_index = 0
        self.image = self.frames[int(self.frame_index)]

    def update(self):
        self.animate()


# создание класса для самого уровня
class LEVEL:
    def __init__(self, level_data, surface, change_coins, change_health):
        self.display_surface = surface
        character_layout = import_csv_layout(level_data['character'])
        self.character = pygame.sprite.GroupSingle()
        self.character_setup(character_layout, change_health)
        self.change_coins = change_coins

        # добавление камеры которая будет следовать за персонажем
        self.camera = CAMERA()

        # импорт всех слоев из карты TILED
        tileBACK_layout = import_csv_layout(level_data['tilemapBEHIND'])
        self.tileBACK_map = self.level_structure(tileBACK_layout, 'tilemapBEHIND')

        tile_layout = import_csv_layout(level_data['tileMAP'])
        self.tile_map = self.level_structure(tile_layout, 'tileMAP')

        light_layout = import_csv_layout(level_data['lightCOIN'])
        self.light_map = self.level_structure(light_layout, 'lightCOIN')

        vine_layout = import_csv_layout(level_data['vines'])
        self.vine_map = self.level_structure(vine_layout, 'vines')

        spikes_layout = import_csv_layout(level_data['spikes'])
        self.spikes_map = self.level_structure(spikes_layout, 'spikes')

        plant_layout = import_csv_layout(level_data['plant'])
        self.plant_map = self.level_structure(plant_layout, 'plant')

        rockTall_layout = import_csv_layout(level_data['rockTALL'])
        self.rockTALL_map = self.level_structure(rockTall_layout, 'rockTALL')

        rockSmall_layout = import_csv_layout(level_data['rockSMALL'])
        self.rockSMALL_map = self.level_structure(rockSmall_layout, 'rockSMALL')

        enemyslime_layout = import_csv_layout(level_data['enemySLIME'])
        self.enemyslime_map = self.level_structure(enemyslime_layout, 'enemySLIME')

        self.miscellaneous = CAMERA()
        self.miscellaneous.add(self.character.sprite)

    # функция импорта всех спрайтов на карту
    def level_structure(self, layout, type):
        # прорисовка плиток
        sprite_group = CAMERA()
        if type == 'tileMAP':
            terrain_tile = import_cut(
                'SPRITES/tilesMAP/Mossy - TileSet17922.png')

        if type == 'tilemapBEHIND':
            terrain_tile = import_cut(
                'SPRITES/tilesMAP/Mossy - TileSet1792TRANS.png')

        # прорисовка декораций и противников
        for lineX_index, lineX in enumerate(layout):
            for lineY_index, lineY in enumerate(lineX):
                if lineY != '-1':
                    x = lineY_index * tileSIZE
                    y = lineX_index * tileSIZE
                    if type == 'tileMAP':
                        tile_surface = terrain_tile[int(lineY)]
                        sprite = STATICFILE(tileSIZE, x, y, tile_surface)

                    if type == 'tilemapBEHIND':
                        tile_surface = terrain_tile[int(lineY)]
                        sprite = STATICFILE(tileSIZE, x, y, tile_surface)

                    if type == 'lightCOIN':
                        sprite = COIN(tileSIZE, x, y)

                    if type == 'vines':
                        sprite = VINE(tileSIZE, x, y)

                    if type == 'plant':
                        sprite = PLANT(tileSIZE, x, y)

                    if type == 'spikes':
                        sprite = SPIKES(tileSIZE, x, y)

                    if type == 'rockTALL':
                        sprite = ROCKTALL(tileSIZE, x, y)

                    if type == 'rockSMALL':
                        sprite = ROCKSMALL(tileSIZE, x, y)

                    if type == 'enemySLIME':
                        sprite = SLIME(tileSIZE, x, y)

                    sprite_group.add(sprite)

        return sprite_group

    # помещение персонажа на карту
    def character_setup(self, layout, changehealth):
        for lineX_index, lineX in enumerate(layout):
            for lineY_index, lineY in enumerate(lineX):
                x = lineY_index * tileSIZE
                y = lineX_index * tileSIZE

                # начало игрока
                if lineY == '0':
                    sprite = CHARACTER((x, y), self.display_surface, changehealth)
                    self.character.add(sprite)

    # столкновение персонажа со стенками плиток
    def horizontal_movement_collision(self):
        character = self.character.sprite
        character.rect.x += character.direction.x * character.speed
        for sprite in self.tile_map.sprites():
            if sprite.rect.colliderect(character.rect):
                if character.direction.x < 0:
                    character.rect.left = sprite.rect.right
                    character.onleft = True
                    self.current_x = character.rect.left
                elif character.direction.x > 0:
                    character.rect.right = sprite.rect.left
                    character.onright = True
                    self.current_x = character.rect.right

        if character.onleft and (character.rect.left < self.current_x or character.direction.x >= 0):
            character.onleft = False
        if character.onright and (character.rect.right > self.current_x or character.direction.x <= 0):
            character.onright = False

    # столкновение персонажа с потолком и полом плиток
    def vertical_movement_collision(self):
        character = self.character.sprite
        character.get_gravity()
        for sprite in self.tile_map.sprites():
            if sprite.rect.colliderect(character.rect):
                if character.direction.y > 0:
                    character.rect.bottom = sprite.rect.top
                    character.direction.y = 0
                    character.onground = True
                elif character.direction.y < 0:
                    character.rect.top = sprite.rect.bottom
                    character.direction.y = 0
                    character.ontop = True

        if character.onground and character.direction.y < 0 or character.direction.y > 1:
            character.onground = False
        if character.ontop and character.direction.y > 0.1:
            character.ontop = False

    # столкновение с монетами
    def check_coin(self):
        collided_coins = pygame.sprite.spritecollide(self.character.sprite, self.light_map, True)
        if collided_coins:
            for coin in collided_coins:
                self.change_coins(1)
                coinsound = pygame.mixer.Sound("MUSIC/Picked Coin Echo 2.wav")
                coinsound.set_volume(0.2)
                coinsound.play()

    # столкновение со слаймами
    def check_slime(self):
        slime_collission = pygame.sprite.spritecollide(self.character.sprite, self.enemyslime_map, False)

        if slime_collission:
            for slime in slime_collission:
                slime_center = slime.rect.centery
                slime_top = slime.rect.top
                character_bottom = self.character.sprite.rect.bottom
                if slime_top < character_bottom < slime_center and self.character.sprite.direction.y >= 0:
                    slimesound = pygame.mixer.Sound("MUSIC/slime_jump.mp3")
                    slimesound.play()
                    self.character.sprite.direction.y = -15
                    slime.kill()
                else:
                    self.character.sprite.get_damage()

    # обновление всех добавленных на экран спрайтов
    def run(self):
        self.tileBACK_map.target_draw(self.character.sprite)
        self.enemyslime_map.target_draw(self.character.sprite)
        self.enemyslime_map.update()
        self.tile_map.target_draw(self.character.sprite)

        self.miscellaneous.target_draw(self.character.sprite)
        self.light_map.target_draw(self.character.sprite)
        self.vine_map.target_draw(self.character.sprite)
        self.plant_map.target_draw(self.character.sprite)
        self.spikes_map.target_draw(self.character.sprite)
        self.rockTALL_map.target_draw(self.character.sprite)
        self.rockSMALL_map.target_draw(self.character.sprite)
        self.character.update()

        self.horizontal_movement_collision()
        self.vertical_movement_collision()
        self.check_coin()
        self.check_slime()


# класс для отрисовки здоровья и монет на экране
class USERDATA:
    def __init__(self, surface):
        self.display_surface = surface
        self.health = pygame.image.load(
            "SPRITES/otherSprites/heart.png").convert_alpha()
        self.health_rect = self.health.get_rect(topleft=(20, 20))

        self.coin = pygame.image.load(
            "SPRITES/otherSprites/coinlight.png").convert_alpha()
        self.coin_rect = self.coin.get_rect(topleft=(20, 50))
        self.font = pygame.font.Font("ComingSoon.ttf", 20)

    # отрисовка здоровья
    def draw_heart(self, maxhealth):
        self.display_surface.blit(self.health, self.health_rect)
        heart_amount = self.font.render(str(maxhealth), False, "WHITE")
        heart_amount_rect = heart_amount.get_rect(midleft=(self.health_rect.right + 7, self.health_rect.centery))
        self.display_surface.blit(heart_amount, heart_amount_rect)

    # отрисовка монет
    def draw_coin(self, amount):
        self.display_surface.blit(self.coin, self.coin_rect)
        coin_amount = self.font.render(str(amount), False, "WHITE")
        coin_amount_rect = coin_amount.get_rect(midleft=(self.coin_rect.right + 7, self.coin_rect.centery))
        self.display_surface.blit(coin_amount, coin_amount_rect)


# отдельный класс камеры, который следует за персонажем
class CAMERA(pygame.sprite.Group):
    def __init__(self):
        super().__init__()
        self.display_surface = pygame.display.get_surface()
        self.cameraBORDERS = {'left': 400, 'right': 400, 'top': 200, 'bottom': 200}
        self.offset = pygame.math.Vector2()
        self.internal_offset = pygame.math.Vector2()

        l = self.cameraBORDERS['left']
        t = self.cameraBORDERS['top']
        w = self.display_surface.get_size()[0] - (self.cameraBORDERS['left'] + self.cameraBORDERS['right'])
        h = self.display_surface.get_size()[1] - (self.cameraBORDERS['top'] + self.cameraBORDERS['bottom'])
        self.camera_rect = pygame.Rect(l, t, w, h)

    # функция для фиксации камеры на персонаже
    def target_camera(self, character):
        if character.rect.left < self.camera_rect.left:
            self.camera_rect.left = character.rect.left
        if character.rect.right > self.camera_rect.right:
            self.camera_rect.right = character.rect.right
        if character.rect.top < self.camera_rect.top:
            self.camera_rect.top = character.rect.top
        if character.rect.bottom > self.camera_rect.bottom:
            self.camera_rect.bottom = character.rect.bottom

        self.offset.x = self.camera_rect.left - self.cameraBORDERS['left']
        self.offset.y = self.camera_rect.top - self.cameraBORDERS['top']

    # обновление всех спрайтов при движении камеры
    def target_draw(self, character):
        self.target_camera(character)
        for sprite in sorted(self.sprites(), key=lambda sprite: sprite.rect.centery):
            offset_pos = sprite.rect.topleft - self.offset
            self.display_surface.blit(sprite.image, offset_pos)


# создание класса для персонажа
class CHARACTER(pygame.sprite.Sprite):
    def __init__(self, pos, surface, changehealth):
        super().__init__()
        self.display_surface = surface
        self.character_sprites()

        # константы для анимации
        self.frameINDEX = 0
        self.animationSPEED = 0.3
        self.image = self.character_animation['2BlueWizardIdle'][self.frameINDEX]
        self.rect = self.image.get_rect(topleft=pos)

        # константы для движения
        self.direction = pygame.math.Vector2()
        self.speed = 8
        self.gravity = 0.8
        self.jumpSPEED = -20

        # константы, связанные с здоровьем
        self.changehealth = changehealth
        self.invincibility = False
        self.invinc_dur = 600
        self.hurt_time = 0

        # статус персонажа
        self.status = 'idle'
        self.facingside = True
        self.onground = False
        self.ontop = False
        self.onleft = False
        self.onright = False

    # импорт анимации
    def character_sprites(self):
        characterPATH = 'SPRITES/ANIMATION/'
        self.character_animation = {'2BlueWizardIdle': [], '2BlueWizardJump': [], '2BlueWizardWalk': [],
                                    '2BlueWizardFall': []}

        for animation in self.character_animation.keys():
            path = characterPATH + animation
            self.character_animation[animation] = import_folder(path)

    # анимация персонажа
    def animate(self):
        animation = self.character_animation[self.status]

        self.frameINDEX += self.animationSPEED
        if self.frameINDEX >= len(animation):
            self.frameINDEX = 0

        # условие для поворота персонажа направо и налево
        image = self.image = animation[int(self.frameINDEX)]
        if self.facingside:
            self.image = image
        else:
            imageFLIP = pygame.transform.flip(image, True, False)
            self.image = imageFLIP

        if self.invincibility:
            alpha = self.cd_flicker()
            self.image.set_alpha(alpha)
        else:
            self.image.set_alpha(255)

    # нажатие клавиш
    def press_key(self):
        key = pygame.key.get_pressed()

        if key[pygame.K_RIGHT] or key[pygame.K_d]:
            self.direction.x = 1
            self.facingside = True
        elif key[pygame.K_LEFT] or key[pygame.K_a]:
            self.direction.x = -1
            self.facingside = False
        else:
            self.direction.x = 0

        if key[pygame.K_SPACE] and self.onground:
            self.jump()
            jump_sound = pygame.mixer.Sound("MUSIC/jump_02.wav")
            jump_sound.set_volume(0.7)
            jump_sound.play()

    # переключение анимаций при прыжке, падении и ходьбе
    # анимация без движения (idle) базовая
    def get_status(self):
        if self.direction.y < 0:
            self.status = '2BlueWizardJump'
        elif self.direction.y > 0:
            self.status = '2BlueWizardFall'
        else:
            if self.direction.x != 0:
                self.status = '2BlueWizardWalk'
            else:
                self.status = '2BlueWizardIdle'

    # гравитация персонажа после прыжка
    def get_gravity(self):
        self.direction.y += self.gravity
        self.rect.y += self.direction.y

    # прыжок
    def jump(self):
        self.direction.y = self.jumpSPEED

    # получение урона
    def get_damage(self):
        if not self.invincibility:
            self.changehealth(-10)
            self.invincibility = True
            self.hurt_time = pygame.time.get_ticks()

    # "охлаждение" персонажа после столкновения
    def cooldown(self):
        if self.invincibility:
            curr_time = pygame.time.get_ticks()
            if curr_time - self.hurt_time >= self.invinc_dur:
                self.invincibility = False

    # мерцание персонажа при столкновении с противником
    def cd_flicker(self):
        flicker = sin(pygame.time.get_ticks())
        if flicker >= 0:
            return 255
        else:
            return 0

    # обновление всех спрайтов
    def update(self):
        self.press_key()
        self.get_status()
        self.animate()
        self.cooldown()
        self.cd_flicker()


# класс для анимации противников (слаймов)
class SLIME(ANIMATEDSPRITES):
    def __init__(self, size, x, y):
        super().__init__(size, x, y, "SPRITES/SlimeGreen")

    def update(self):
        self.animate()


# словарь для слоёв спрайтов на карте игры
level0_map = {
    'character': 'TIlED/leveltile/TILESET0._beginend.csv',
    'tileMAP': 'TILED/leveltile/TILESET0._tilemap.csv',
    'enemySLIME': 'TILED/leveltile/TILESET0._enemyslime.csv',
    'lightCOIN': 'TILED/leveltile/TILESET0._light.csv',
    'tilemapBEHIND': 'TILED/leveltile/TILESET0._behindmap.csv',
    'spikes': 'TILED/leveltile/TILESET0._spikes.csv',
    'vines': 'TILED/leveltile/TILESET0._vines.csv',
    'plant': 'TILED/leveltile/TILESET0._leaves.csv',
    'rockTALL': 'TILED/leveltile/TILESET0._rock1.csv',
    'rockSMALL': 'TILED/leveltile/TILESET0._rock2.csv'
}


# класс для инициализации игры
class GAME:
    def __init__(self):
        self.health = 100
        self.coins = 0

        # добавление фоновой музыки
        self.bgmusic = pygame.mixer.Sound("MUSIC/bgmusic.mp3")
        self.bgmusic.play(loops=-1)

        self.level = LEVEL(level0_map, screen, self.change_coins, self.change_health)
        self.userdata = USERDATA(screen)
        self.font_end = pygame.font.Font("ComingSoon.ttf", 30)

    # прибавление монет
    def change_coins(self, amount):
        self.coins += amount

    # изменение здоровья
    def change_health(self, amount):
        self.health += amount

    # окончание игры
    def gameover(self):
        if self.health <= 0:
            image = pygame.image.load(
                "SPRITES/otherSprites/death screen.png")
            screen.blit(image, (0, 0))

        if self.coins == 30:
            image = pygame.image.load(
                "SPRITES/otherSprites/win screen.png")
            screen.blit(image, (0, 0))

    # вызов уровня, прорисовка монет и здоровья
    def run(self):
        self.level.run()

        self.userdata.draw_heart(self.health)
        self.userdata.draw_coin(self.coins)


game = GAME()

# запуск игры
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

    image = pygame.image.load(
        "SPRITES/otherSprites/screen.png")
    screen.blit(image, (0, 0))

    game.run()
    game.gameover()
    pygame.display.update()

    clock.tick(30)  # фпс игры
